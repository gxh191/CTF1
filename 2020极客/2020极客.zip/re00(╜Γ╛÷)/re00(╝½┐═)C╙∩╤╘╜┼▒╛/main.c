#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a[]={23,  29,   7,  63,  55,  45,  41,  52,  40,  33,
   27,  55,  45,  41,  52,  40,  33,  27,  60,  43,
   54,  54,  54,  27,  54,  45,  35,  44,  48, 123,
  123,  57};
  int b[31];
  int i;
  for(i=0;i<=31;i++)
  {
   b[i]=a[i]^68;
  }
  for(i=0;i<=31;i++)
  {
    printf("%x",b[i]);
  }
    return 0;
}
