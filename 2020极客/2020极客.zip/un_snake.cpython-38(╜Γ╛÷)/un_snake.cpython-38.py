# uncompyle6 version 3.7.4
# Python bytecode 3.8 (3413)
# Decompiled from: Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: ./un_snake.py
# Compiled at: 2020-08-05 16:20:40
# Size of source mod 2**32: 1238 bytes
import this
from base64 import *

def pre(data):
    th1s = 'TBESCFSRSAEUITANAIIN'.encode() 
    if (data_len := len(data)) > (th1s_len := len(th1s)): 
        th1s = th1s * (data_len // th1s_len) + th1s[:data_len - th1s_len]         
    return bytes(map(lambda x, y: x ^ y, data, th1s))


def enc(plain):
    plain = list(plain)  #将plain转换为列表
    plain = plain[::-1]#反转字符串
    for i in range(len(plain)):#测量plain的长度，并依次以1递增的方式赋给i
        c = plain[i]
        plain[i] = (c << 3 | c >> 5) & 255             #位移操作
    else:                                                                                     
        for i in range(len(plain) - 1):

            plain[i] ^= plain[(i + 1)]             #顺序异或
        else:
            return bytes(plain) 


def check(a):
    return b64encode(a) == b'mEiQCAjJoXJy2NiZQGGQyRm6IgHYQZAICKgowHHo4Dg='
 


if __name__ == '__main__':
    print()
    while True:
        stuff = input('Now input you flag:')
        stuff_ready = pre(stuff.encode())   #将输入的字符串以utf-8的格式编码加密后送入pre函数
        result = check(enc(stuff_ready))  #pre函数运行的结果送入enc函数
                                                                #enc函数运行后送入check函数  结束
        if result:
            print('You get it! Python is so charming right?')
            break
        else:
            print('Failed, try again!')

    print('[🐍] Commit you flag, see you next time!')
