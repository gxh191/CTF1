﻿hard 8：
矩阵运算 python-Z3

hard 9：
base64加密 算法

hard 10:
c++ 时间差反调试 计算 梅森随机数生成算法

hard 11:
C++ SMC TEA加密

hard 12:
VM

hard 13:
SM4 VM

hard 14:
C++ 复杂算法

hard 15:
C++ boost库分割解析字符串 24点游戏 爆破

hard 16:
反调试 多线程 Windows编程 NTFS文件流 Aes md5

hard 17:
C++ boost库分割解析字符串 Z3

hard 18:
Unicorn 大端序mips32(mips-linux-gnu-gcc在ubuntu1604下编译) 42元一次方程 矩阵求解 

hard20：
dnspy添加代码打log  全排列与组合

hard21：
C++ 切割字符串  重新排序  Serpent算法  CRC进行.text段校验

hard22：
花指令  反调试  SMC TEA加密